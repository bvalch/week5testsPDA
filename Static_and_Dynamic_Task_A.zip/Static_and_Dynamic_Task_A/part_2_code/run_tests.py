import unittest
from tests.card_game_tests import TestCardGame

if __name__ == "__main__":
    unittest.main()